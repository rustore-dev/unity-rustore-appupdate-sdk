namespace RuStore.AppUpdate {

    public enum UpdateFlowResult {

        RESULT_OK = -1,
        RESULT_CANCELED = 0,
        RESULT_ACTIVITY_NOT_FOUND = 2,
    }
}
