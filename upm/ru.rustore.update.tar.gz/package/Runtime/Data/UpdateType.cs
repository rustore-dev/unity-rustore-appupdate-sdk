namespace RuStore.AppUpdate {

    public enum UpdateType {

        FLEXIBLE,
        IMMEDIATE,
        SILENT,
    }
}
