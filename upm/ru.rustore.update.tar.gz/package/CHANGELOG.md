## История изменений

### Release 6.1.0
- Версия SDK appUpdate 6.1.0.
- RuStoreSDK помещена в отдельную assembly.


### Release 6.0.0
- Версия SDK appUpdate 6.+.
- Изменена структура репозитория.
- Добавлен проект с исходным кодом .aar пакетов.


### Release 3.0.0
- Версия SDK appUpdate 3.+.


### Release 2.0.0
- Версия SDK appUpdate 2.+.


### Release 0.2.1
- Исправлены зависимости SDK.


### Release 0.2.0
- Версия SDK appUpdate 0.2.0.
