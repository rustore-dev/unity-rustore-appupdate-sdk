﻿
namespace RuStore.AppUpdate {

    public interface IInstallStateUpdateListener {

           public void OnStateUpdated(InstallState state);
    }
}